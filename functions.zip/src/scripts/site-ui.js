(() => {
        const base = document.body.dataset.siteBase || '/';
        const imageUrl = (path) => /^(?:https?:|data:|blob:)/i.test(String(path || '')) ? String(path || '') : `${base}${String(path || '').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/')}`;
        const normalize = (value) => String(value || '')
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')
          .toLocaleLowerCase('pt-BR')
          .trim();
        const formatBRL = (value) => new Intl.NumberFormat('pt-BR', {
          style: 'currency', currency: 'BRL', minimumFractionDigits: 2,
        }).format(Number(value) || 0);
        const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

        const menuButton = document.querySelector('.nav-toggle');
        const menu = document.querySelector('.nav-links');
        menuButton?.addEventListener('click', () => {
          const open = menuButton.getAttribute('aria-expanded') === 'true';
          menuButton.setAttribute('aria-expanded', String(!open));
          menu?.classList.toggle('open', !open);
        });

        document.querySelectorAll('[data-random-carousel]').forEach((track) => {
          const sequences = [...track.querySelectorAll('.carousel-sequence')];
          if (sequences.length < 2) return;
          const firstItems = [...sequences[0].children];
          for (let index = firstItems.length - 1; index > 0; index -= 1) {
            const swap = Math.floor(Math.random() * (index + 1));
            [firstItems[index], firstItems[swap]] = [firstItems[swap], firstItems[index]];
          }
          firstItems.forEach((item) => sequences[0].appendChild(item));
          const keyOf = (item) => item.dataset.productId || item.getAttribute('href') || item.textContent;
          const secondItems = [...sequences[1].children];
          const buckets = new Map();
          secondItems.forEach((item) => {
            const key = keyOf(item);
            const list = buckets.get(key) || [];
            list.push(item);
            buckets.set(key, list);
          });
          firstItems.forEach((item) => {
            const match = buckets.get(keyOf(item))?.shift();
            if (match) sequences[1].appendChild(match);
          });
        });

        const parseImageList = (value) => {
          try {
            const parsed = JSON.parse(value || '[]');
            return Array.isArray(parsed) ? parsed.filter(Boolean) : [];
          } catch (_) { return []; }
        };

        const initImage = (image) => {
          if (!image || image.dataset.fallbackReady === 'true') return;
          if (image.dataset.deferLoad === 'true' && !image.getAttribute('src')) return;
          image.dataset.fallbackReady = 'true';
          const candidates = parseImageList(image.dataset.imageCandidates);
          const gallery = parseImageList(image.dataset.imageGallery);
          let nextIndex = 0;
          const stage = image.closest('[data-image-stage], .image-stage');
          const showImage = () => { image.hidden = false; stage?.classList.remove('no-image'); };
          const tryNext = () => {
            if (nextIndex < candidates.length) {
              showImage();
              image.src = candidates[nextIndex++];
              return;
            }
            image.hidden = true;
            stage?.classList.add('no-image');
          };
          const startGallery = () => {
            if (gallery.length < 2 || gallery.length > 12 || image.dataset.galleryReady === 'true') return;
            image.dataset.galleryReady = 'true';
            Promise.all(gallery.map((url) => new Promise((resolve) => {
              const probe = new Image();
              probe.onload = () => resolve(url);
              probe.onerror = () => resolve(null);
              probe.src = url;
            }))).then((loaded) => {
              const valid = [...new Set(loaded.filter(Boolean))];
              if (valid.length < 2) return;
              let index = Math.max(0, valid.findIndex((url) => new URL(url, document.baseURI).href === image.currentSrc));
              image.src = valid[index];
              const seed = [...(image.alt || '')].reduce((sum, char) => sum + char.charCodeAt(0), 0);
              let galleryTransitioning = false;
              const waitForImage = (target) => new Promise((resolve) => {
                if (target.complete && target.naturalWidth > 0) {
                  if (typeof target.decode === 'function') target.decode().catch(() => {}).finally(resolve);
                  else resolve();
                  return;
                }
                target.addEventListener('load', resolve, { once: true });
                target.addEventListener('error', resolve, { once: true });
              });
              const swapGalleryImage = async (url) => {
                if (galleryTransitioning || !stage || !url) return;
                galleryTransitioning = true;

                const preload = new Image();
                preload.src = url;
                await waitForImage(preload);
                if (!preload.naturalWidth) {
                  galleryTransitioning = false;
                  return;
                }

                const overlay = document.createElement('img');
                overlay.className = 'gallery-transition-image';
                overlay.alt = '';
                overlay.setAttribute('aria-hidden', 'true');
                overlay.src = url;
                stage.appendChild(overlay);
                await waitForImage(overlay);

                requestAnimationFrame(() => overlay.classList.add('is-visible'));
                window.setTimeout(async () => {
                  image.src = url;
                  await waitForImage(image);
                  overlay.classList.add('is-settled');
                  window.setTimeout(() => {
                    overlay.remove();
                    galleryTransitioning = false;
                  }, 90);
                }, reducedMotion ? 0 : 420);
              };
              window.setInterval(() => {
                if (document.hidden || galleryTransitioning) return;
                index = (index + 1) % valid.length;
                swapGalleryImage(valid[index]);
              }, 2800 + (seed % 900));
            });
          };
          image.addEventListener('load', () => { showImage(); startGallery(); });
          image.addEventListener('error', tryNext);
          if (image.complete) image.naturalWidth > 0 ? (showImage(), startGallery()) : tryNext();
        };
        document.querySelectorAll('img[data-image-candidates]').forEach(initImage);

        const initTilt = (element) => {
          if (!finePointer || reducedMotion || !element || element.dataset.tiltReady === 'true') return;
          element.dataset.tiltReady = 'true';
          let frame = 0;
          element.addEventListener('pointermove', (event) => {
            cancelAnimationFrame(frame);
            frame = requestAnimationFrame(() => {
              const bounds = element.getBoundingClientRect();
              const x = Math.max(0, Math.min(1, (event.clientX - bounds.left) / bounds.width));
              const y = Math.max(0, Math.min(1, (event.clientY - bounds.top) / bounds.height));
              const strength = Number(element.dataset.tiltStrength || 8);
              element.style.setProperty('--mx', `${x * 100}%`);
              element.style.setProperty('--my', `${y * 100}%`);
              element.style.setProperty('--ry', `${(x - .5) * strength * 2}deg`);
              element.style.setProperty('--rx', `${(.5 - y) * strength * 2}deg`);
              element.classList.add('is-tilting');
            });
          });
          element.addEventListener('pointerleave', () => {
            cancelAnimationFrame(frame);
            element.style.setProperty('--rx', '0deg');
            element.style.setProperty('--ry', '0deg');
            element.style.setProperty('--mx', '50%');
            element.style.setProperty('--my', '50%');
            element.classList.remove('is-tilting');
          });
        };
        document.querySelectorAll('[data-tilt]').forEach(initTilt);

        const hydrateDynamic = (container = document) => {
          container.querySelectorAll?.('img[data-image-candidates]').forEach(initImage);
          container.querySelectorAll?.('[data-tilt]').forEach(initTilt);
        };
        window.VaultHydrate = hydrateDynamic;
        window.dispatchEvent(new CustomEvent('vault:hydrator-ready'));

        document.querySelectorAll('[data-catalog-root]').forEach((root) => {
          const grid = root.querySelector('[data-catalog-grid]');
          const items = Array.from(root.querySelectorAll('[data-catalog-item]'));
          const search = root.querySelector('[data-filter-search]');
          const collection = root.querySelector('[data-filter-collection]');
          const condition = root.querySelector('[data-filter-condition]');
          const type = root.querySelector('[data-filter-type]');
          const owner = root.querySelector('[data-filter-owner]');
          const sort = root.querySelector('[data-filter-sort]');
          const clear = root.querySelector('[data-filter-clear]');
          const count = root.querySelector('[data-result-count]');
          const empty = root.querySelector('[data-empty-state]');

          const compare = (a, b, mode) => {
            const priceA = Number(a.dataset.price || -1);
            const priceB = Number(b.dataset.price || -1);
            const nameA = normalize(a.dataset.name);
            const nameB = normalize(b.dataset.name);
            if (mode === 'price-asc') return priceA - priceB || nameA.localeCompare(nameB, 'pt-BR');
            if (mode === 'name-asc') return nameA.localeCompare(nameB, 'pt-BR');
            if (mode === 'quantity-desc') return Number(b.dataset.quantity || 0) - Number(a.dataset.quantity || 0) || nameA.localeCompare(nameB, 'pt-BR');
            return priceB - priceA || nameA.localeCompare(nameB, 'pt-BR');
          };

          const apply = () => {
            const query = normalize(search?.value);
            const selectedCollection = collection?.value || '';
            const selectedCondition = condition?.value || '';
            const selectedType = type?.value || '';
            const selectedOwner = owner?.value || '';
            const mode = sort?.value || 'price-desc';
            let visible = 0;
            items.sort((a, b) => compare(a, b, mode)).forEach((item) => {
              grid?.appendChild(item);
              const matches = (!query || normalize(item.dataset.search).includes(query))
                && (!selectedCollection || item.dataset.filterCollection === selectedCollection)
                && (!selectedCondition || item.dataset.filterCondition === selectedCondition)
                && (!selectedType || item.dataset.filterType === selectedType)
                && (!selectedOwner || item.dataset.filterOwner === selectedOwner);
              item.hidden = !matches;
              if (matches) visible += 1;
            });
            if (count) count.textContent = String(visible);
            empty?.classList.toggle('show', visible === 0);
          };

          [search, collection, condition, type, owner, sort].forEach((control) =>
            control?.addEventListener(control === search ? 'input' : 'change', apply));
          clear?.addEventListener('click', () => {
            [search, collection, condition, type, owner].forEach((control) => { if (control) control.value = ''; });
            if (sort) sort.value = 'price-desc';
            apply();
            search?.focus();
          });
          const params = new URLSearchParams(window.location.search);
          if (search && params.get('q')) search.value = params.get('q');
          apply();
        });

        const modal = document.querySelector('[data-product-modal]');
        const modalPanel = modal?.querySelector('.product-modal-panel');
        const modalMedia = modal?.querySelector('[data-modal-media]');
        const modalName = modal?.querySelector('[data-modal-name]');
        const modalNumber = modal?.querySelector('[data-modal-number]');
        const modalType = modal?.querySelector('[data-modal-type]');
        const modalCondition = modal?.querySelector('[data-modal-condition]');
        const modalStock = modal?.querySelector('[data-modal-stock]');
        const modalDescription = modal?.querySelector('[data-modal-description]');
        const modalPrice = modal?.querySelector('[data-modal-price]');
        const modalPricePanel = modal?.querySelector('[data-modal-price-panel]');
        const modalProposal = modal?.querySelector('[data-modal-add-proposal]');
        const modalPurchaseActions = modal?.querySelector('[data-modal-purchase-actions]');
        const modalOwner = modal?.querySelector('[data-modal-owner]');
        const modalOwnerCollection = modal?.querySelector('[data-modal-owner-collection]');
        const modalOwnerAvatar = modal?.querySelector('[data-modal-owner-avatar]');
        const modalOwnerLink = modal?.querySelector('[data-modal-owner-link]');
        const modalKitDetails = modal?.querySelector('[data-modal-kit-details]');
        const modalKitGallery = modal?.querySelector('[data-modal-kit-gallery]');
        const modalKitList = modal?.querySelector('[data-modal-kit-list]');
        const modalKitDiscount = modal?.querySelector('[data-modal-kit-discount]');
        const modalTags = modal?.querySelector('[data-modal-tags]');
        const modalCardCondition = modal?.querySelector('[data-modal-card-condition]');
        const modalCardConditionValue = modal?.querySelector('[data-modal-card-condition-value]');
        const rarityTier = (value = '') => {
          const rarity = normalize(value);
          const compact = rarity.replace(/[^a-z0-9]+/g, '');
          const premium = ['full art','ultra rara','ultra rare','secret','secreta','gold','dourad','rainbow','illustration rare','ilustracao rara','arte rara','special illustration','sir','alt art','galeria de treinador','trainer gallery','shiny rare','shiny ultra','hyper rare'].some((token) => rarity.includes(token)) || ['ru','sr','re'].includes(rarity);
          if (premium) return 'premium';
          const holo = ['holo','foil','reverse','radiante','radiant','vmax','v-astro','vstar','mega ex',' ex','gx',' v','rh','rl','rd'].some((token) => rarity.includes(token)) || /^(?:mega\s+)?(?:ex|gx|v(?:max|star|-astro|-union)?)(?:\b|\s|—|-)/.test(rarity) || /^(?:ex|gx|v|vmax|vstar|v-astro|megaex|rh|rl|rd|s)$/.test(compact);
          return holo ? 'holo' : 'basic';
        };
        let activeProductCard = null;
        let modalReturnFocus = null;

        const buildKitEntryVisual = (entry) => {
          const isCardEntry = entry?.kind !== 'boosters';
          const visual = document.createElement('div');
          visual.className = isCardEntry ? `collectible-visual detail-visual foil-tier-${rarityTier(entry?.type || '')}` : 'collectible-visual booster-visual detail-visual';
          visual.dataset.tilt = '';
          visual.dataset.tiltStrength = isCardEntry ? '8' : '5';
          const stage = document.createElement('div');
          stage.className = 'image-stage';
          const candidates = Array.isArray(entry?.imageCandidates) ? entry.imageCandidates.map((value) => String(value || '')).filter(Boolean) : [];
          if (candidates.length) {
            let cursor = 0;
            const image = document.createElement('img');
            image.alt = entry?.name || 'Item do kit';
            image.loading = 'lazy';
            image.decoding = 'async';
            image.dataset.imageCandidates = JSON.stringify(candidates.slice(1));
            image.src = imageUrl(candidates[cursor]);
            image.addEventListener('error', () => {
              cursor += 1;
              if (candidates[cursor]) image.src = imageUrl(candidates[cursor]);
              else image.remove();
            });
            stage.appendChild(image);
          } else {
            const fallback = document.createElement('span');
            fallback.className = 'kit-gallery-fallback';
            fallback.textContent = String(entry?.name || 'TC').slice(0, 2).toUpperCase();
            stage.appendChild(fallback);
          }
          if (isCardEntry) {
            const holoBand = document.createElement('span'); holoBand.className = 'holo-band';
            const foil = document.createElement('span'); foil.className = 'foil-spectrum';
            const glare = document.createElement('span'); glare.className = 'glare';
            stage.append(holoBand, foil, glare);
          }
          visual.appendChild(stage);
          initTilt(visual);
          return visual;
        };

        const createVirtualProductCard = (entry = {}) => {
          const isCardEntry = entry?.kind !== 'boosters';
          const article = document.createElement('article');
          article.dataset.kind = isCardEntry ? 'card' : 'booster';
          article.dataset.name = String(entry?.name || 'Item do kit');
          article.dataset.number = String(entry?.number || '');
          article.dataset.collection = String(entry?.collection || '');
          article.dataset.language = String(entry?.language || '');
          article.dataset.condition = String(entry?.condition || '');
          article.dataset.year = String(entry?.year || '');
          article.dataset.type = isCardEntry ? String(entry?.type || 'Carta') : 'Booster avulso';
          article.dataset.description = isCardEntry ? 'Carta incluída neste kit.' : 'Booster incluído neste kit.';
          article.dataset.contents = '';
          article.dataset.linkLiga = String(entry?.linkLiga || '');
          article.dataset.kitItems = '[]';
          article.dataset.kitDiscount = '0';
          article.dataset.kitSourceTotal = '';
          article.dataset.owner = String(entry?.ownerName || activeProductCard?.dataset?.owner || 'Colecionador');
          article.dataset.ownerCollection = String(entry?.ownerCollectionName || activeProductCard?.dataset?.ownerCollection || 'Coleção');
          article.dataset.ownerSlug = String(entry?.ownerCollectionSlug || activeProductCard?.dataset?.ownerSlug || '');
          article.dataset.ownerPhone = String(entry?.ownerPhone || activeProductCard?.dataset?.ownerPhone || '');
          article.dataset.proposalPolicy = 'none';
          article.dataset.proposalFlexible = 'false';
          article.dataset.proposalTiers = '[]';
          article.dataset.proposalAllowed = 'false';
          const priceValue = Number(entry?.unitPrice);
          article.dataset.priceValue = Number.isFinite(priceValue) ? String(priceValue) : '';
          article.dataset.priceLabel = Number.isFinite(priceValue) ? formatBRL(priceValue) : 'Consultar';
          article.dataset.stock = String(Math.max(1, Number(entry?.quantity) || 1));
          article.dataset.forSale = 'false';
          article.dataset.showQuantity = 'false';
          article.appendChild(buildKitEntryVisual(entry));
          return article;
        };

        const openKitEntryPreview = (entry, trigger) => {
          const virtualCard = createVirtualProductCard(entry || {});
          openModal(virtualCard, trigger);
        };

        const setSpec = (selector, value, visible = true) => {
          const row = modal?.querySelector(selector);
          if (!row) return;
          row.hidden = !visible;
          const node = row.querySelector('dd');
          if (node) node.textContent = value || 'Não informado';
        };
        const closeModal = () => {
          if (!modal || modal.hidden) return;
          modal.classList.remove('open');
          window.setTimeout(() => { modal.hidden = true; }, reducedMotion ? 0 : 180);
          document.body.classList.remove('modal-open');
          modalReturnFocus?.focus?.();
        };
        const openModal = (card, trigger) => {
          if (!modal || !modalMedia) return;
          activeProductCard = card;
          modalReturnFocus = trigger;
          const kind = card.dataset.kind || 'card';
          const isCard = kind === 'card';
          const isBooster = kind === 'booster';
          const isKit = kind === 'kit';
          const isProduct = kind === 'product';
          const visual = card.querySelector('.collectible-visual');
          modalMedia.innerHTML = visual ? visual.outerHTML : '';
          const clonedVisual = modalMedia.querySelector('[data-tilt]');
          if (clonedVisual) {
            clonedVisual.classList.add('detail-visual');
            clonedVisual.dataset.tiltStrength = '11';
            delete clonedVisual.dataset.tiltReady;
            initTilt(clonedVisual);
          }
          modalMedia.querySelectorAll('img[data-image-candidates]').forEach((clonedImage) => {
            delete clonedImage.dataset.fallbackReady;
            initImage(clonedImage);
          });

          modal.classList.toggle('card-modal', isCard);
          modal.classList.toggle('booster-modal', isBooster);
          modal.classList.toggle('kit-modal', isKit);
          modal.classList.toggle('sealed-product-modal', isProduct);
          if (modalTags) modalTags.hidden = isCard || isKit || isBooster;
          if (modalName) modalName.textContent = card.dataset.name || '';
          if (modalNumber) {
            modalNumber.hidden = isCard;
            modalNumber.textContent = isBooster ? 'Pacote lacrado' : isKit ? 'Conjunto personalizado' : isProduct ? 'Produto lacrado' : '';
          }
          if (modalType) { modalType.hidden = isCard || isKit || isBooster; modalType.textContent = card.dataset.type || ''; }
          if (modalStock) {
            const showQuantity = !isKit && card.dataset.showQuantity === 'true';
            modalStock.hidden = !showQuantity;
            modalStock.textContent = showQuantity ? `${card.dataset.stock || '0'} ${card.dataset.stock === '1' ? 'unidade' : 'unidades'}` : '';
          }
          if (modalDescription) modalDescription.textContent = card.dataset.description || (isCard
            ? 'Carta publicada por um colecionador da comunidade Vault TCG.'
            : isBooster ? 'Booster lacrado publicado por um colecionador da comunidade.' : isKit ? 'Conjunto personalizado pelo dono da coleção.' : 'Produto Pokémon lacrado publicado pelo colecionador.');
          if (modalPrice) modalPrice.textContent = card.dataset.priceLabel || 'Consultar';
          modalPricePanel?.classList.toggle('booster-price-panel', isBooster);
          if (modalPurchaseActions) modalPurchaseActions.hidden = card.dataset.proposalAllowed === 'false';

          if (modalCondition) {
            modalCondition.hidden = true;
            modalCondition.textContent = card.dataset.condition || '';
            modalCondition.className = `condition-badge condition-${normalize(card.dataset.condition).replace(/\s+/g, '-')}`;
          }
          if (modalCardCondition) {
            const condition = String(card.dataset.condition || '').trim().toUpperCase();
            modalCardCondition.hidden = !isCard || !condition;
            modalCardCondition.className = `modal-card-condition condition-${normalize(condition).replace(/\s+/g, '-')}`;
            if (modalCardConditionValue) modalCardConditionValue.textContent = condition;
          }
          const ownerName = card.dataset.owner || 'Colecionador';
          if (modalOwner) modalOwner.textContent = ownerName;
          if (modalOwnerCollection) modalOwnerCollection.textContent = card.dataset.ownerCollection || '';
          if (modalOwnerAvatar) modalOwnerAvatar.textContent = ownerName.slice(0, 2).toUpperCase();
          if (modalOwnerLink) modalOwnerLink.href = `${base}colecao/?slug=${encodeURIComponent(card.dataset.ownerSlug || '')}`;

          setSpec('[data-spec-pokemon-collection]', card.dataset.collection || '', isCard || isBooster);
          setSpec('[data-spec-number]', card.dataset.number || '', false);
          setSpec('[data-spec-language]', card.dataset.language || '', isCard);
          setSpec('[data-spec-condition]', card.dataset.condition || '', false);
          setSpec('[data-spec-year]', card.dataset.year || '', isCard);
          setSpec('[data-spec-type]', card.dataset.type || '', !isCard && !isKit);
          setSpec('[data-spec-contents]', card.dataset.contents || '', false);

          if (modalKitDetails) {
            modalKitDetails.hidden = !isKit;
            if (modalKitGallery) modalKitGallery.hidden = !isKit;
            if (isKit) {
              let kitItems = [];
              try { kitItems = JSON.parse(card.dataset.kitItems || '[]'); } catch (_) { kitItems = []; }
              if (modalKitDiscount) {
                const discount = Number(card.dataset.kitDiscount || 0);
                modalKitDiscount.textContent = discount > 0 ? `${discount.toLocaleString('pt-BR', { maximumFractionDigits: 1 })}% de desconto` : 'Sem desconto';
              }
              if (modalKitGallery) {
                modalKitGallery.innerHTML = '';
                kitItems.forEach((entry) => {
                  const figure = document.createElement('figure');
                  const isKitCard = entry.kind !== 'boosters';
                  const visual = buildKitEntryVisual(entry);
                  if (isKitCard) {
                    figure.tabIndex = 0;
                    figure.setAttribute('role', 'button');
                    figure.setAttribute('aria-label', `Abrir detalhes de ${entry.name || 'carta do kit'}`);
                    figure.classList.add('modal-kit-gallery-entry');
                    figure.addEventListener('click', () => openKitEntryPreview(entry, figure));
                    figure.addEventListener('keydown', (event) => {
                      if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        openKitEntryPreview(entry, figure);
                      }
                    });
                  }
                  figure.appendChild(visual);
                  const caption = document.createElement('figcaption');
                  caption.textContent = entry.name || 'Item';
                  figure.appendChild(caption);
                  if (isKitCard) {
                    const hint = document.createElement('small');
                    hint.className = 'modal-kit-gallery-hint';
                    hint.textContent = 'Abrir carta';
                    figure.appendChild(hint);
                  }
                  modalKitGallery.appendChild(figure);
                });
              }
              if (modalKitList) {
                modalKitList.innerHTML = '';
                kitItems.forEach((entry) => {
                  const li = document.createElement('li');
                  const qty = Math.max(1, Number(entry.quantity) || 1);
                  const amount = document.createElement('strong');
                  const name = document.createElement('span');
                  amount.textContent = `${qty}×`;
                  name.textContent = String(entry.name || 'Item');
                  li.append(amount, name);
                  modalKitList.appendChild(li);
                });
              }
            }
          }

          modal.hidden = false;
          document.body.classList.add('modal-open');
          requestAnimationFrame(() => modal.classList.add('open'));
          modalPanel?.focus?.();
        };
        modal?.querySelectorAll('[data-modal-close]').forEach((button) => button.addEventListener('click', closeModal));

        const storageKey = 'nexus-tcg-proposals-v1';
        let proposals = [];
        let activeOwnerSlug = '';
        let proposalSubmitBusy = false;
        try {
          const saved = JSON.parse(localStorage.getItem(storageKey) || '[]');
          if (Array.isArray(saved)) proposals = saved.filter((group) => group?.ownerSlug && Array.isArray(group.items));
        } catch (_) {}

        const proposalDrawer = document.querySelector('[data-proposal-drawer]');
        const proposalBackdrop = document.querySelector('[data-proposal-backdrop]');
        const proposalCount = document.querySelector('[data-proposal-count]');
        const proposalList = document.querySelector('[data-proposal-collection-list]');
        const proposalEmpty = document.querySelector('[data-proposal-empty]');
        const proposalAuthRequired = document.querySelector('[data-proposal-auth-required]');
        const proposalAuthLink = document.querySelector('[data-proposal-auth-link]');
        const proposalEditor = document.querySelector('[data-proposal-editor]');
        const proposalItems = document.querySelector('[data-proposal-items]');
        const proposalDiscount = document.querySelector('[data-proposal-discount]');
        const proposalReason = document.querySelector('[data-proposal-reason]');
        const proposalBuyerName = document.querySelector('[data-proposal-buyer-name]');
        const proposalAddress = document.querySelector('[data-proposal-address]');
        const proposalError = document.querySelector('[data-proposal-error]');
        const checkoutModal = document.querySelector('[data-checkout-modal]');
        const checkoutPanel = checkoutModal?.querySelector('.checkout-panel');
        const checkoutMessage = checkoutModal?.querySelector('[data-checkout-message]');
        const checkoutWhatsapp = checkoutModal?.querySelector('[data-checkout-whatsapp]');
        const checkoutCopy = checkoutModal?.querySelector('[data-checkout-copy]');
        const checkoutOwner = checkoutModal?.querySelector('[data-checkout-owner]');
        const checkoutPhone = checkoutModal?.querySelector('[data-checkout-phone]');
        const checkoutNote = checkoutModal?.querySelector('[data-checkout-note]');

        const policyLabels = {
          flexible: 'Sou flexível quanto às regras',
          none: 'Não aceito propostas',
          fixed_price_multi_only: 'Sem proposta para cartas precificadas e somente com mais de um produto',
          no_defined_price: 'Sem proposta para cartas com preço definido',
          multi_only: 'Propostas somente com mais de um produto',
        };
        const parseJson = (value, fallback) => { try { return JSON.parse(value || '') ?? fallback; } catch (_) { return fallback; } };
        const normalizePhone = (value) => {
          const digits = String(value || '').replace(/\D/g, '');
          if (!digits) return '';
          return digits.startsWith('55') ? digits : `55${digits}`;
        };
        const saveProposals = () => localStorage.setItem(storageKey, JSON.stringify(proposals));
        const activeGroup = () => proposals.find((group) => group.ownerSlug === activeOwnerSlug) || proposals[0] || null;
        const groupQuantity = (group) => group.items.reduce((sum, item) => sum + item.quantity, 0);
        const groupTotal = (group) => group.items.reduce((sum, item) => Number.isFinite(item.price) ? sum + item.price * item.quantity : sum, 0);
        const itemLabel = (item) => item.number || (item.kind === 'kit' ? 'Kit' : item.kind === 'card' ? 'Carta avulsa' : item.kind === 'booster' ? 'Booster avulso' : 'Produto lacrado');
        const requiresMultiple = (policy) => policy === 'multi_only' || policy === 'fixed_price_multi_only';
        const maxDiscountFor = (group) => {
          if (!group) return 0;
          if (group.terms.policy === 'fixed_price_multi_only' && group.items.some((item) => item.kind === 'card' && Number.isFinite(item.price))) return 0;
          if (group.terms.flexibleDiscounts) return 100;
          const total = groupTotal(group);
          return [...(group.terms.discountTiers || [])]
            .sort((left, right) => Number(left.minValue) - Number(right.minValue))
            .reduce((limit, tier) => total >= Number(tier.minValue) ? Number(tier.maxDiscount) : limit, 0);
        };
        const finalTotalFor = (group) => groupTotal(group) * (1 - Math.max(0, Number(group.discount || 0)) / 100);

        const productFromCard = (card) => {
          const image = card.querySelector('.image-stage img');
          return {
            id: card.dataset.productId || '', kind: card.dataset.kind || 'card', name: card.dataset.name || 'Produto',
            number: card.dataset.number || '', owner: card.dataset.owner || 'Colecionador',
            ownerCollection: card.dataset.ownerCollection || '', ownerSlug: card.dataset.ownerSlug || '', ownerPhone: card.dataset.ownerPhone || '', ownerUid: card.dataset.ownerUid || '',
            price: card.dataset.priceValue === '' ? null : Number(card.dataset.priceValue), priceLabel: card.dataset.priceLabel || 'Consultar',
            image: image && !image.hidden ? (image.currentSrc || image.src || '') : '', quantity: 1,
            stock: Math.max(1, Number(card.dataset.stock || 1)),
            terms: {
              policy: card.dataset.proposalPolicy || 'flexible',
              flexibleDiscounts: card.dataset.proposalFlexible !== 'false',
              discountTiers: parseJson(card.dataset.proposalTiers, []),
            },
          };
        };

        const feedbackButton = (button, label = 'Adicionado') => {
          const original = button?.innerHTML;
          if (!button) return;
          button.innerHTML = `<span aria-hidden="true">✓</span> ${label}`;
          button.classList.add('added');
          window.setTimeout(() => { button.innerHTML = original; button.classList.remove('added'); }, 1100);
        };

        const createProposalItem = (item) => {
          const article = document.createElement('article');
          article.className = 'proposal-item';
          article.dataset.proposalItemId = item.id;
          const thumb = document.createElement('div');
          thumb.className = 'proposal-item-thumb';
          if (item.image) { const image = document.createElement('img'); image.src = item.image; image.alt = ''; thumb.appendChild(image); }
          else thumb.textContent = (item.name || '?').slice(0, 2).toUpperCase();
          const content = document.createElement('div');
          content.className = 'proposal-item-content';
          const title = document.createElement('strong'); title.textContent = item.name;
          const meta = document.createElement('span'); meta.textContent = itemLabel(item);
          const price = document.createElement('b'); price.textContent = item.priceLabel;
          content.append(title, meta, price);
          const controls = document.createElement('div');
          controls.className = 'proposal-item-controls';
          const decrease = document.createElement('button'); decrease.type = 'button'; decrease.dataset.proposalAction = 'decrease'; decrease.textContent = '−'; decrease.setAttribute('aria-label', 'Diminuir quantidade');
          const quantity = document.createElement('span'); quantity.textContent = String(item.quantity);
          const increase = document.createElement('button'); increase.type = 'button'; increase.dataset.proposalAction = 'increase'; increase.textContent = '+'; increase.setAttribute('aria-label', 'Aumentar quantidade');
          const remove = document.createElement('button'); remove.type = 'button'; remove.dataset.proposalAction = 'remove'; remove.className = 'proposal-item-remove'; remove.textContent = 'Remover';
          controls.append(decrease, quantity, increase, remove);
          article.append(thumb, content, controls);
          return article;
        };

        const syncActiveForm = (group) => {
          if (!group) return;
          if (proposalDiscount) proposalDiscount.value = String(group.discount ?? 0);
          if (proposalReason) proposalReason.value = group.reason || '';
          if (proposalBuyerName) proposalBuyerName.value = group.buyerName || '';
          if (proposalAddress) proposalAddress.value = group.address || '';
        };

        let proposalUser = null;
        const setProposalAuthState = (user) => {
          proposalUser = user || null;
          const signedIn = Boolean(proposalUser);
          if (proposalAuthRequired) proposalAuthRequired.hidden = signedIn;
          if (proposalList) proposalList.hidden = !signedIn;
          if (proposalEmpty) proposalEmpty.hidden = !signedIn || Boolean(activeGroup());
          if (proposalEditor) proposalEditor.hidden = !signedIn || !activeGroup();
          if (proposalAuthLink) proposalAuthLink.href = `${base}cadastro/?next=${encodeURIComponent(window.location.pathname + window.location.search)}`;
        };
        const refreshProposalAuth = async () => {
          try {
            await window.VaultCloud?.ready;
            const user = await window.VaultCloud?.currentUser?.();
            setProposalAuthState(user);
            return user;
          } catch (_) {
            setProposalAuthState(null);
            return null;
          }
        };

        const renderProposals = () => {
          proposals = proposals.filter((group) => group.items.length > 0);
          if (!activeOwnerSlug || !proposals.some((group) => group.ownerSlug === activeOwnerSlug)) activeOwnerSlug = proposals[0]?.ownerSlug || '';
          const totalItems = proposals.reduce((sum, group) => sum + groupQuantity(group), 0);
          if (proposalCount) proposalCount.textContent = String(totalItems);
          proposalList?.replaceChildren(...proposals.map((group) => {
            const button = document.createElement('button');
            button.type = 'button'; button.dataset.proposalGroup = group.ownerSlug;
            button.className = group.ownerSlug === activeOwnerSlug ? 'active' : '';
            const avatar = document.createElement('span'); avatar.textContent = String(group.owner || 'CO').slice(0, 2).toUpperCase();
            const copy = document.createElement('div');
            const owner = document.createElement('strong'); owner.textContent = group.owner;
            const amount = document.createElement('small'); amount.textContent = `${groupQuantity(group)} ${groupQuantity(group) === 1 ? 'item' : 'itens'}`;
            const total = document.createElement('b'); total.textContent = formatBRL(groupTotal(group));
            copy.append(owner, amount); button.append(avatar, copy, total);
            return button;
          }));
          const group = activeGroup();
          if (proposalEmpty) proposalEmpty.hidden = !proposalUser || Boolean(group);
          if (proposalEditor) proposalEditor.hidden = !proposalUser || !group;
          if (!group) { saveProposals(); return; }
          document.querySelector('[data-proposal-owner-avatar]').textContent = String(group.owner || 'CO').slice(0, 2).toUpperCase();
          document.querySelector('[data-proposal-owner]').textContent = group.owner;
          document.querySelector('[data-proposal-collection]').textContent = group.ownerCollection;
          document.querySelector('[data-proposal-policy-label]').textContent = policyLabels[group.terms.policy] || policyLabels.flexible;
          const tiers = group.terms.discountTiers || [];
          const termsText = group.terms.flexibleDiscounts
            ? 'O colecionador marcou os descontos como flexíveis.'
            : tiers.length
              ? `Limites: ${tiers.map((tier) => `a partir de ${formatBRL(tier.minValue)}, até ${tier.maxDiscount}%`).join(' · ')}.`
              : 'Nenhum desconto foi liberado nos termos atuais.';
          document.querySelector('[data-proposal-terms-summary]').textContent = termsText;
          proposalItems?.replaceChildren(...group.items.map(createProposalItem));
          const published = groupTotal(group);
          const maxDiscount = maxDiscountFor(group);
          group.discount = Math.max(0, Math.min(Number(group.discount || 0), maxDiscount));
          document.querySelector('[data-proposal-published-total]').textContent = formatBRL(published);
          document.querySelector('[data-proposal-final-total]').textContent = formatBRL(finalTotalFor(group));
          if (proposalDiscount) { proposalDiscount.max = String(maxDiscount); proposalDiscount.value = String(group.discount); }
          const limit = document.querySelector('[data-proposal-discount-limit]');
          if (limit) limit.textContent = group.terms.flexibleDiscounts ? 'Desconto flexível: informe o percentual que deseja negociar.' : `Máximo permitido nesta proposta: ${maxDiscount}%.`;
          if (proposalError) proposalError.hidden = true;
          syncActiveForm(group);
          saveProposals();
        };

        const addToProposal = async (card, button) => {
          const user = proposalUser || await refreshProposalAuth();
          if (!user) {
            feedbackButton(button, 'Entre para adicionar');
            openProposalDrawer();
            return;
          }
          if (card.dataset.proposalAllowed === 'false') { feedbackButton(button, 'Não permitido'); return; }
          const product = productFromCard(card);
          let group = proposals.find((entry) => entry.ownerSlug === product.ownerSlug);
          if (!group) {
            group = { ownerSlug: product.ownerSlug, ownerUid: product.ownerUid, owner: product.owner, ownerCollection: product.ownerCollection, phone: product.ownerPhone, terms: product.terms, items: [], discount: 0, reason: '', buyerName: '', address: '' };
            proposals.push(group);
          } else {
            // Atualiza propostas salvas no navegador antes da migração online.
            group.ownerUid = product.ownerUid || group.ownerUid || '';
            group.owner = product.owner || group.owner || '';
            group.ownerCollection = product.ownerCollection || group.ownerCollection || '';
            group.phone = product.ownerPhone || group.phone || '';
            group.terms = product.terms || group.terms;
          }
          const current = group.items.find((item) => item.id === product.id);
          if (current) current.quantity = Math.min(current.stock, current.quantity + 1);
          else group.items.push(product);
          activeOwnerSlug = group.ownerSlug;
          renderProposals();
          feedbackButton(button, 'Na proposta');
        };

        const openProposalDrawer = async () => {
          closeModal();
          if (!proposalDrawer || !proposalBackdrop) return;
          proposalBackdrop.hidden = false;
          proposalDrawer.setAttribute('aria-hidden', 'false');
          document.body.classList.add('proposal-open');
          requestAnimationFrame(() => { proposalBackdrop.classList.add('open'); proposalDrawer.classList.add('open'); });
          const user = proposalUser || await refreshProposalAuth();
          setProposalAuthState(user);
          if (user) renderProposals();
        };
        const closeProposalDrawer = () => {
          if (!proposalDrawer || !proposalBackdrop) return;
          proposalBackdrop.classList.remove('open'); proposalDrawer.classList.remove('open');
          proposalDrawer.setAttribute('aria-hidden', 'true'); document.body.classList.remove('proposal-open');
          window.setTimeout(() => { proposalBackdrop.hidden = true; }, reducedMotion ? 0 : 180);
        };
        const closeCheckout = () => {
          if (!checkoutModal || checkoutModal.hidden) return;
          checkoutModal.classList.remove('open'); document.body.classList.remove('checkout-open');
          window.setTimeout(() => { checkoutModal.hidden = true; }, reducedMotion ? 0 : 180);
        };

        const showProposalError = (message) => {
          if (!proposalError) return;
          proposalError.textContent = message; proposalError.hidden = false;
        };
        const validateGroup = (group) => {
          if (!group?.items.length) return 'Adicione pelo menos um produto.';
          if (group.terms.policy === 'none') return 'Este colecionador não aceita propostas.';
          if (requiresMultiple(group.terms.policy) && group.items.length < 2) return 'Os termos exigem pelo menos dois produtos diferentes nesta proposta.';
          const maxDiscount = maxDiscountFor(group);
          if (Number(group.discount || 0) > maxDiscount) return `O desconto máximo permitido para esta seleção é ${maxDiscount}%.`;
          if (!String(group.buyerName || '').trim()) return 'Informe seu nome completo.';
          if (String(group.address || '').trim().length < 20) return 'Informe o endereço completo para entrega, incluindo número, cidade, estado e CEP.';
          if (Number(group.discount || 0) > 0 && !String(group.reason || '').trim()) return 'Explique o motivo do desconto solicitado.';
          return '';
        };
        const lineForItem = (item) => {
          const subtotal = Number.isFinite(item.price) ? formatBRL(item.price * item.quantity) : 'valor a consultar';
          const unit = Number.isFinite(item.price) ? ` (${formatBRL(item.price)} cada)` : '';
          return `- ${item.quantity}x ${item.name}${item.number ? ` — ${item.number}` : ''}${unit} — ${subtotal}`;
        };
        const buildCheckoutMessage = (group) => {
          const published = groupTotal(group);
          const finalTotal = finalTotalFor(group);
          const discount = Number(group.discount || 0);
          const lines = [
            `Olá, ${group.owner}!`,
            '',
            `Gostaria de enviar uma proposta formal pelos itens abaixo da coleção “${group.ownerCollection}”:`,
            '',
            ...group.items.map(lineForItem),
            '',
            `Valor publicado dos itens com preço definido: ${formatBRL(published)}`,
            `Desconto geral solicitado: ${discount}%`,
            `Valor proposto: ${formatBRL(finalTotal)}`,
          ];
          if (group.items.some((item) => !Number.isFinite(item.price))) lines.push('Há item(ns) com valor a consultar; peço que sejam confirmados antes da aceitação.');
          lines.push('', `Motivo: ${group.reason || 'Não informado.'}`);
          lines.push('', 'DADOS PARA ENTREGA', `Nome: ${group.buyerName}`, `Endereço: ${group.address}`);
          lines.push('', 'FORMA DE PAGAMENTO', 'Pagamento por Pix, após a aceitação da proposta e a confirmação da disponibilidade dos itens.');
          lines.push('', 'Esta mensagem foi gerada pelo Vault TCG de acordo com os termos públicos da coleção.');
          return lines.join('\n');
        };
        const openCheckout = async () => {
          if (proposalSubmitBusy) return;
          const group = activeGroup();
          const error = validateGroup(group);
          if (error) { showProposalError(error); return; }
          proposalSubmitBusy = true;
          const reviewButton = document.querySelector('[data-proposal-review]');
          if (reviewButton) reviewButton.disabled = true;
          let submitted = null;
          try {
            await window.VaultCloud?.ready;
            const user = await window.VaultCloud?.currentUser?.();
            if (!user) { closeCheckout(); openProposalDrawer(); return; }
            group.publishedTotal = groupTotal(group);
            group.proposedTotal = finalTotalFor(group);
            if (!window.VaultCloud?.submitProposal) throw new Error('O módulo de negociações do Vault não foi carregado. Atualize a página e tente novamente.');
            submitted = await window.VaultCloud.submitProposal(group);
            if (!submitted?.proposal?.id) throw new Error('O servidor não confirmou o registro da proposta. Tente novamente.');
          } catch (cloudError) {
            showProposalError(window.VaultCloud?.friendlyFirebaseError?.(cloudError) || cloudError?.message || 'Não foi possível registrar a proposta.');
            return;
          } finally {
            proposalSubmitBusy = false;
            if (reviewButton) reviewButton.disabled = false;
          }
          const message = buildCheckoutMessage(group);
          const phone = normalizePhone(group.phone);
          if (checkoutMessage) checkoutMessage.value = message;
          if (checkoutWhatsapp) {
            checkoutWhatsapp.hidden = !phone;
            checkoutWhatsapp.href = phone ? `https://web.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(message)}` : '#';
          }
          if (checkoutOwner) checkoutOwner.textContent = group.owner;
          if (checkoutPhone) checkoutPhone.textContent = group.phone || 'não informado';
          if (checkoutNote) checkoutNote.textContent = submitted?.notification?.sent === false
            ? 'A proposta foi registrada no Vault. O Gmail do vendedor não pôde ser enviado agora; a negociação continua disponível normalmente.'
            : 'A proposta foi registrada no Vault e o vendedor recebeu uma notificação por Gmail. Acompanhe as respostas em Meu Vault → Negociações.';
          proposals = proposals.filter((entry) => entry !== group);
          activeOwnerSlug = proposals[0]?.ownerSlug || '';
          renderProposals();
          closeProposalDrawer();
          checkoutModal.hidden = false; document.body.classList.add('checkout-open');
          requestAnimationFrame(() => checkoutModal.classList.add('open'));
          checkoutPanel?.focus?.();
        };
        const copyCheckoutMessage = async () => {
          const message = checkoutMessage?.value || '';
          if (!message) return;
          try { await navigator.clipboard.writeText(message); }
          catch (_) { checkoutMessage?.focus(); checkoutMessage?.select(); document.execCommand('copy'); checkoutMessage?.setSelectionRange(0, 0); }
          feedbackButton(checkoutCopy, 'Mensagem copiada');
        };

        document.querySelectorAll('[data-proposal-open]').forEach((button) => button.addEventListener('click', openProposalDrawer));
        document.querySelectorAll('[data-proposal-close]').forEach((button) => button.addEventListener('click', closeProposalDrawer));
        document.querySelectorAll('[data-checkout-close]').forEach((button) => button.addEventListener('click', closeCheckout));
        proposalBackdrop?.addEventListener('click', closeProposalDrawer);
        checkoutCopy?.addEventListener('click', copyCheckoutMessage);
        document.querySelector('[data-proposal-review]')?.addEventListener('click', openCheckout);
        document.querySelector('[data-proposal-clear]')?.addEventListener('click', () => {
          const group = activeGroup();
          if (!group || !window.confirm(`Excluir a proposta para ${group.owner}?`)) return;
          proposals = proposals.filter((entry) => entry.ownerSlug !== group.ownerSlug); activeOwnerSlug = proposals[0]?.ownerSlug || ''; renderProposals();
        });
        proposalList?.addEventListener('click', (event) => {
          const button = event.target.closest('[data-proposal-group]');
          if (!button) return; activeOwnerSlug = button.dataset.proposalGroup; renderProposals();
        });
        proposalItems?.addEventListener('click', (event) => {
          const button = event.target.closest('[data-proposal-action]');
          const itemElement = event.target.closest('[data-proposal-item-id]');
          const group = activeGroup();
          if (!button || !itemElement || !group) return;
          const index = group.items.findIndex((item) => item.id === itemElement.dataset.proposalItemId);
          if (index < 0) return;
          if (button.dataset.proposalAction === 'increase') group.items[index].quantity = Math.min(group.items[index].stock, group.items[index].quantity + 1);
          if (button.dataset.proposalAction === 'decrease') group.items[index].quantity -= 1;
          if (button.dataset.proposalAction === 'remove' || group.items[index].quantity <= 0) group.items.splice(index, 1);
          renderProposals();
        });
        const updateActiveField = (field, value) => {
          const group = activeGroup(); if (!group) return;
          group[field] = value; if (proposalError) proposalError.hidden = true; saveProposals();
          if (field === 'discount') renderProposals();
        };
        proposalDiscount?.addEventListener('input', (event) => updateActiveField('discount', Math.max(0, Number(event.target.value || 0))));
        proposalReason?.addEventListener('input', (event) => updateActiveField('reason', event.target.value));
        proposalBuyerName?.addEventListener('input', (event) => updateActiveField('buyerName', event.target.value));
        proposalAddress?.addEventListener('input', (event) => updateActiveField('address', event.target.value));

        document.addEventListener('click', (event) => {
          const openButton = event.target.closest('[data-open-product]');
          if (openButton) {
            const card = openButton.closest('[data-product-card]');
            if (card) openModal(card, openButton);
            return;
          }
          const proposalButton = event.target.closest('[data-add-proposal]');
          if (proposalButton) {
            const card = proposalButton.closest('[data-product-card]');
            if (card) addToProposal(card, proposalButton);
          }
        });
        modalProposal?.addEventListener('click', () => { if (activeProductCard) addToProposal(activeProductCard, modalProposal); });
        document.addEventListener('keydown', (event) => {
          if (event.key === 'Escape') { closeModal(); closeProposalDrawer(); closeCheckout(); }
          if (event.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName || '')) {
            const search = document.querySelector('[data-filter-search]');
            if (search) { event.preventDefault(); search.focus(); }
          }
        });
        renderProposals();
        refreshProposalAuth().then(() => renderProposals());
        window.addEventListener('vault:auth-changed', (event) => {
          setProposalAuthState(event.detail?.user || null);
          renderProposals();
        });

        document.querySelectorAll('[data-reveal]').forEach((element) => element.classList.add('reveal-ready'));
        if ('IntersectionObserver' in window && !reducedMotion) {
          const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
            if (entry.isIntersecting) { entry.target.classList.add('revealed'); observer.unobserve(entry.target); }
          }), { threshold: .08 });
          document.querySelectorAll('.reveal-ready').forEach((element) => observer.observe(element));
        } else document.querySelectorAll('.reveal-ready').forEach((element) => element.classList.add('revealed'));
      })();
